## Overview
iMin machine has a built-in thermal printer, allowing the App to print thermal receipts directly through the sdk, with a printer
The products come with:
 - Handheld Finance Series —— M2-202、M2-203、M2 Pro、Swift 1 ...。
 - Flat panel terminal Series —— M2 Max、D1、D1 Pro、Falcon 1 ...。
 - Desk cash register equipment —— D4 ...

iMin products have two types of built-in printers：
  - 80mm paper width, with cutter, compatible with 58mm, such as Falcon 1 equipped with this printer
  - 58mm 58mm paper width, without cutting knife, such as D1, D1 Pro, M2 Max equipped with this printer


App developers can use flutter mode to call the built-in thermal printer to view[Quick start](/quickstart)Understand the details.
