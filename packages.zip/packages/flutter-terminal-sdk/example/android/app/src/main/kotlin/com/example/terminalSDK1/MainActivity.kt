package com.example.terminalSDK1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
