# Changelog

# 0.6.4
 - fixed  example bug
 - Add openLogs method
 - Add sendRAWDataHexStr method

# 0.6.3
 - fixed  printSingleBitmap To Url bug

# 0.6.2
 - Fixed  bug and Optimize the money box function
 - Fixed Package name collisions  bug

# 0.6.1
 - Fixed bug

## 0.6.0
- Added 1.0 and 2.0 printing apis
- Compatible with iMin devices that use the 1.0 print api and the 2.0 print api
- Fixed the money box opening bugqq

## 0.5.6
- added openCashBox method

## 0.5.5
- added printSingleBitmap And printMultiBitmap Supports network url printing  method

## 0.5.4
- added setTextStyle method

## 0.5.3
- changed setTextStyle method
- edited  andorid jar libs

## 0.5.2

- Included printAndLineFeed method
- Included printAndFeedPaper method
- Included partialCut method
- Included setAlignment method
- Included setTextSize method
- Included setTextTypeface method
- Included setTextStyle method
- Included setTextLineSpacing method
- Included setTextWidth method
- Included printAntiWhiteText method
- Included printColumnsText method
- Included setBarCodeWidth method
- Included setBarCodeHeight method
- Included setBarCodeContentPrintPos method
- Included printBarCode method
- Included setLeftMargin method
- Included setPageFormat method
- Included printSingleBitmap method
- Included printMultiBitmap method
- Included printSingleBitmapBlackWhite method
- Included setDoubleQRSize method
- Included setDoubleQR1Level method
- Included setDoubleQR2Level method
- Included setDoubleQR1MarginLeft method
- Included setDoubleQR2MarginLeft method
- Included setDoubleQR1Version method
- Included setDoubleQR2Version method
- Included printDoubleQR method
- Included setInitIminPrinter method
- Included resetDevice method

## 0.5.1

- 0.5.1 release

## 0.5.0

- 0.5.0 release

## 0.4.3

- 0.4.3 release

## 0.4.2

- 0.4.2 release

## 0.4.1

- 0.4.1 release

## 0.4.0

- 0.4.0 release
- Update Readme
- Included Qrcode print
- Included text print
